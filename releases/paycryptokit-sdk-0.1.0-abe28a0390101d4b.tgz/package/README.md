# @yourpay/sdk

Server API client and signed webhook verification for a YourPay deployment. Package/domain names are provisional until the repository owner publishes a release.

API calls accept an optional `AbortSignal`: `pay.createNativeInvoice(savedInput, { signal })`, `pay.getInvoice(id, { signal })`, and `pay.listInvoices({ limit: 50, signal })` (also supported by native quotes, receipt pages and the invoice iterator). Cancellation is combined with the client's existing `timeoutMs` deadline, including response-body reading. An already aborted signal starts no request. Cancellation stops waiting; it cannot undo an order already accepted by the server. Preserve the same saved IDs/parameters for recovery, and query the existing invoice when available. The SDK never automatically retries creation after cancellation or timeout.

For merchant BTC/LTC investigations, `pay.listNativeReceipts(invoiceId, { limit: 50, before })` reads `/api/v1/native/invoices/:id/receipts`. Reuse the returned opaque `nextCursor` until it is null; limits are 1–100. Each receipt exposes transaction hash, output index, atomic amount and recorded block height/hash/time. Numeric monetary and block values are strings. The endpoint checks merchant ownership even if checkout is disabled; cursors are bound to the invoice. Refresh from the first page for newly discovered evidence, since pagination is not a frozen snapshot. Combine with `getInvoice(id).nativePayment` for monitoring/hold context: recorded evidence does not guarantee current canonical inclusion and cannot authorize fulfillment by itself.

```ts
import { YourPay, readWebhookBody, verifyWebhook } from '@yourpay/sdk';

const pay = new YourPay({
  baseUrl: process.env.YOURPAY_API_URL!,
  apiKey: process.env.YOURPAY_API_KEY!,
});

// Run only on the server. Load this order and its amount from your own database.
const invoice = await pay.createInvoice({
  orderId: order.id,
  amount: order.amount,
  network: order.network,
  asset: 'USDC',
  title: order.title,
});
```

Redirect the customer to `invoice.checkoutUrl`. The browser-only export also provides `openCheckout({checkoutUrl, onComplete})` for an iframe dialog; verify wallet support in the embedded context before enabling it. Completion callbacks are UI hints only.

```ts
const event = verifyWebhook(
  await readWebhookBody(request),
  request.headers.get('yourpay-signature'),
  process.env.YOURPAY_WEBHOOK_SECRET!,
);
```

Verify raw bytes before parsing or fulfillment. For `payment.completed`, match the order's amount, asset and network, and atomically persist the unique event ID and purchased entitlement in your database. Duplicate deliveries are a successful no-op. Return non-2xx on transient failures. Expiry notifications may arrive before a genuine late-discovered payment completion; never downgrade a paid order on a delayed expiry event.

`readWebhookBody(request, { maxBytes: 65536, timeoutMs: 10000 })` bounds the raw body before verification, including requests without a Content-Length header. The defaults are 64 KiB and ten seconds. It cancels oversized/stalled input, rejects invalid UTF-8 and preserves the received UTF-8 text for HMAC verification. Body limits are positive safe integers; timeout must fit a Node timer. This deadline covers body reading, not fulfillment. Keep ingress request limits and business/database timeouts configured too. Newly generated CLI webhook routes use this helper; existing integrations must adopt it explicitly, since the CLI never overwrites their files.

API keys belong on the server. The hosted service charges 0.2% separately from network fees; supported payment networks come from that deployment's `/api/networks` response.

## EVM address-payment diagnostics

`pay.getInvoiceOperations(invoiceId, { signal })` reads a merchant-owned snapshot from `/api/v1/invoices/:id/operations`. It reports deposit scan position, errors as boolean flags, finality holds and the active sweep (or latest completed job). It never returns raw signed bytes, execution configuration or RPC error messages. Other payment methods currently return `available: false`; this does not mean payment failed. `pendingOver30Minutes` is an advisory age threshold measured from job creation, not a deadline or failure verdict. `needsOperatorReview` does not trigger execution. A confirmed sweep still requires independent payment settlement; use verified Webhooks for fulfillment.

## Native BTC/LTC API (opt-in)

Native invoice endpoints require a verified merchant receiving branch and the operator's `invoiceApiEnabled: true` network setting. `pay.getNetworks()` returns separate `nativeNetworks` entries with exact network IDs, assets and API enablement; these are configuration information, not proof of worker health or merchant eligibility. Do not use roadmap entries as payment options.

Native hosted checkout implements address/amount display, amount-bearing QR, address-only QR and explicit wallet-request links. Browser fixtures and local Core-node payment tests provide separate evidence; real wallet interoperability and public-network acceptance remain open. These methods do not establish commercial readiness.

```ts
// Server-side: persist requestId with your order before calling the API.
const quote = await pay.createNativeQuote({
  requestId: order.quoteRequestId,
  orderId: order.id,
  network: order.nativeNetwork,
  denomination: 'USD',
  amount: order.amount,
});
// Persist quote.id and the snapshot for reconciliation. Obtain a new quote
// with a new persisted requestId only when intentionally accepting a new price.
if (quote.expired) throw new Error('A fresh quote is required');
const nativeInvoice = await pay.createNativeInvoice({
  quoteId: quote.id,
  title: order.title,
});
// Persist nativeInvoice.id with the merchant order before returning this URL.
// Redirect the customer to nativeInvoice.checkoutUrl from your website.
```

Use `getNativeQuote(id)` to inspect a saved snapshot, including its database-clock expiry flag. The server rechecks expiry when accepting; a client check cannot extend validity. Amounts are decimal strings, with at most six USD or eight native decimal places. Rates and confirmation counts come from the server. `YourPayError` preserves HTTP status and error code, including `price_unavailable`, `network_unavailable`, `invoice_conflict` and `insufficient_credit`.

Transport retries must reuse the original quote request ID or invoice quote/options. The SDK never automatically fetches a new price or accepts a replacement quote. After an uncertain acceptance response, retry the same acceptance or query merchant invoice history before starting another purchase. A quote's short acceptance deadline is distinct from the accepted invoice's payment deadline. Snapshot native amounts, asset and network must be checked against payment events; a USD-priced order is not numerically equal to its BTC/LTC amount.

`Invoice` and `PaymentEvent.data` now include BTC/LTC assets and bitcoin/litecoin families; stable-token `createInvoice` inputs remain USDC/USDT only. Consumers with exhaustive asset/family handling must add native cases. Existing invoice lookup, listing and iteration work for native invoices too. No browser private key or merchant API key belongs in this flow.

## Invoice history

Stream merchant invoices newest first without loading every page into memory:

```ts
for await (const invoice of pay.iterateInvoices({ limit: 100 })) {
  await reconcileWithYourOrder(invoice);
  // Breaking the loop stops further page requests.
}
```

For a paginated UI, call `pay.listInvoices({ limit: 50 })`, then pass its `nextCursor` unchanged as `before` on the next call. A null cursor means the end. Cursors retain full database time precision and an order ID to preserve timestamp ties. Treat them as opaque; do not derive them from the displayed `createdAt`. `iterateInvoices` also accepts `before` to resume from a saved cursor.

Refresh from the first page to see newly created invoices. Traversal is not a transactional snapshot: invoice status can change between requests. Existing ISO timestamp `before` bounds remain supported as exclusive cutoffs, but cannot recover ties skipped by an older timestamp-only cursor; restart from the first page to obtain the new cursor.

## Customer network and token selection

Add `paymentOptions: [{ network: 'configured-evm-a', asset: 'USDC' }, { network: 'configured-evm-b', asset: 'USDT' }]` to an invoice whose default `network`/`asset` is included. Use only pairs actually enabled by your deployment. The same nominal amount applies to every option. Save that list with the merchant order before creating the invoice and validate completion against it. The hosted checkout fixes one choice before signing, keeps one fee reservation, and rejects later changes. Idempotent creation retries use the original request parameters.
# Webhook validation options

`verifyWebhook` verifies the original raw request body. Its optional `now` and `toleranceSeconds` values use integer Unix seconds and nonnegative integer seconds respectively; both must be safe integers. Defaults are the current time and 300 seconds. Zero tolerance requires the exact timestamp. Invalid values such as `NaN`, infinity, negatives or fractions throw rather than disabling timestamp checks.

The verifier rejects empty event/invoice/order IDs and completion or expiry events whose status/kind contradict their type. Expired payment and credit invoices both use `payment.expired`. Merchants must still match the amount, asset, network and order against their own authoritative records and atomically persist event deduplication with fulfillment. Signature verification is not a replacement for those business checks.
## API response limits

API calls retain the configured request deadline while reading the body. Responses are limited to 1 MiB of decoded bytes by default, including gzip responses. Set constructor option `maxResponseBytes` to an integer from 1 to 16777216 for larger legitimate responses; prefer pagination. Oversized responses throw `YourPayError` with code `response_too_large`; malformed JSON, invalid UTF-8 or a non-object envelope throws `invalid_response`. Neither error includes the raw response. An error after creating an invoice does not prove the order was rejected: query its status and reuse the original identifiers/options. The SDK does not automatically retry writes.

The server SDK uses manual redirect handling, including on Cloudflare Workers. Every HTTP redirect is rejected with `redirect_rejected` before reading its body or requesting its target; authorization and invoice writes are never forwarded. Configure the canonical API origin directly. Workers consumers must enable Node.js compatibility for the SDK's webhook cryptography.
