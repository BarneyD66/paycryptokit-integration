# YourPay MCP

Connect an AI client's MCP tools to your merchant account through a local stdio process. Uses the [official MCP TypeScript SDK](https://ts.sdk.modelcontextprotocol.io/server). Requires Node.js 24+, a running YourPay API and a merchant API key. Packages are currently local release artifacts; they have not been published to npm.

## Start from this repository

For an existing CLI browser login, install/build the CLI, SDK and MCP packages together, run `yourpay login --url https://your-deployment`, then `yourpay mcp`. Copy the resulting secret-free `mcpServers` configuration into your client. It points `YOURPAY_CREDENTIALS_FILE` at the existing local login file, so you do not copy an API key. Remove any `YOURPAY_API_URL`/`YOURPAY_API_KEY` variables from that MCP process: combining sources is rejected. Restart MCP after changing the saved login; revocation is checked by the API on every request. Protect the login file with your OS user permissions. The command prints configuration only and does not change client files.

Run `npm ci` and `npm run build --workspace @yourpay/sdk` at the repository root. Set `YOURPAY_API_URL` to the API origin and `YOURPAY_API_KEY` to your merchant key in your client's secret/environment settings, then add this MCP server:

```json
{
  "mcpServers": {
    "yourpay": {
      "command": "node",
      "args": ["E:/个人cryptomus/packages/mcp/bin/yourpay-mcp.mjs"]
    }
  }
}
```

Replace the absolute path with your checkout path. Use an absolute Node executable path if your client cannot find `node`. Client configuration formats vary; the JSON above is for clients accepting `mcpServers`. If the client requires an `env` object, store the API URL/key there in its private local configuration; never commit that configuration or put keys in prompts. This package does not read the CLI's saved credentials automatically. HTTPS is required except on localhost, and URL paths, query strings and embedded credentials are rejected.

For installation outside the repository, build and `npm pack` both `packages/sdk` and `packages/mcp`, then install the resulting two `.tgz` files together. The `yourpay-mcp` executable is the same stdio server. `npm run test:packages` verifies independent installation and protocol calls from the packed binary. MCP's external runtime dependencies require registry access or a prepopulated package cache. No package has been remotely published.

## Tools

| Tool                          | Purpose                                               |
| ----------------------------- | ----------------------------------------------------- |
| `yourpay_integration_status`  | Website/webhook setup and historical payment progress |
| `yourpay_list_networks`       | Discover configured assets and native API enablement  |
| `yourpay_create_invoice`      | Create USDC/USDT checkout on a configured network     |
| `yourpay_get_invoice`         | Read merchant invoice status                          |
| `yourpay_invoice_operations`  | Read EVM address-payment scan/sweep diagnostics       |
| `yourpay_list_invoices`       | Paginated merchant invoice history                    |
| `yourpay_create_native_quote` | Save a BTC/LTC quote on an enabled native network     |
| `yourpay_get_native_quote`    | Read the original quote and expiry                    |
| `yourpay_accept_native_quote` | Accept the saved quote and create checkout            |

Example request to your AI: “List my configured YourPay networks and check integration status, then create a 5 USDC checkout on my selected network for merchant order order-123.” `yourpay_list_networks` returns exact IDs/assets and separate `nativeNetworks` with `invoiceApiEnabled`. Roadmap entries are not payment options. Configuration does not prove live node health, wallet ownership or merchant eligibility. Native quotes require a saved UUID request ID, an enabled API and verified receiving branch.

Creation is a write operation and can reserve fee credit. The host should apply its normal user-authorization policy; MCP annotations describe behavior, they do not enforce authorization. Use amounts from the merchant's trusted order system. Never let untrusted buyer text define a price or grant access to a merchant key. The server offers no arbitrary HTTP, wallet signing, payout, address-changing or secret-reading tool.

On a timeout, the order may already exist. Reuse the original order ID/request UUID/quote and identical options. No automatic write retries or repricing occur. Errors omit upstream messages; inspect your own merchant dashboard for details. Requests use the SDK's 15-second timeout and propagate MCP cancellation. Redirects are refused.

Invoice results may contain customer/order text: treat it as data, not instructions. An AI response or checkout redirect must never grant purchased access. Verify signed webhooks and fulfill atomically in the merchant backend. Status reports explicitly leave business fulfillment unverified. This MCP adapter adds no chain support and does not turn local tests into commercial acceptance.

For BTC/LTC, ask the agent to discover an enabled native network, persist the merchant order and one quote request UUID, create the native quote, then persist and accept that quote with unchanged options. Save the resulting invoice ID before returning its checkout URL. After a timeout, reconcile the original request; do not generate a new quote automatically. The hosted native page offers wallet-request links and QR modes, but the adapter cannot launch or sign with a customer's wallet. Backend webhook verification and idempotent business fulfillment are still required. CLI `init --native` or `connect --native` scaffolds native quote/acceptance routes; implement its order, quote-save, invoice-save and fulfillment hooks against the merchant database. Default templates remain stable-token-only.

## Verification

`npm run test:utxo`, with verified `YOURPAY_BITCOIND` and `YOURPAY_LITECOIND` executable paths, separately exercises MCP invoice acceptance against real isolated Core regtest nodes. Core wallets send two transfers, the scanner confirms and settles, MCP reads the paid state, and a local merchant verifies signed callbacks and grants one entitlement despite a lost acknowledgement. The price/binding setup and loopback merchant transport remain fixtures; this is not public-chain or production HTTPS acceptance.

`npm run test:mcp` exercises real stdio negotiation, tool discovery/calls, strict input validation, retained retry arguments, safe errors and redirect refusal. A separate test reaches the actual local HTTP API with isolated PGlite, verifying one invoice and one fee reservation across retries, changed-order refusal and credential revocation. For BTC/LTC it seeds branch/rate fixtures, verifies quote ownership and replay, and checks disabled/unhealthy invoice acceptance leaves balances and allocations unchanged. Successful native acceptance uses seeded receiving addresses and controlled JSON-RPC responses, then verifies replay without RPC or duplicate invoice/watch/fee reservation. Real descriptor derivation, public chains, wallet payments and business fulfillment are outside these MCP tests.
