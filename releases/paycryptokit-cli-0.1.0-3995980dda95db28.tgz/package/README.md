# @yourpay/cli

CLI and AI integration Skill for YourPay. Install from a verified release tarball until the owner publishes the npm package under a confirmed scope.

`yourpay native-receipts --id <invoice-uuid> --limit 50 [--before <nextCursor>]` reads one page of this merchant's recorded BTC/LTC outputs. Pass cursors unchanged and stop at null. Failed reads exit nonzero; no automatic pagination, payment, settlement or refund is performed. Use `invoice-get` for the associated monitoring/hold context. Receipt evidence alone cannot authorize fulfillment, and refresh starts from the first page to discover newer observations.

```sh
yourpay login --url https://your-actual-payment-deployment
yourpay init --dry-run
yourpay init
yourpay doctor
yourpay skill --install --agent codex
```

Login displays a URL and device code. Open the URL, sign in to your merchant workspace and approve only if the code matches. The returned API key is saved to your OS-user configuration directory; it is never printed by the CLI. Protect that file with your operating system's access controls.

On identity-family-enabled deployments, choose your existing EVM, TRON or Solana identity wallet. For a new merchant, the signed login also authorizes that address as its initial receiver. Signing in with a different wallet creates a separate merchant; it does not link accounts. Additional receiving addresses require ownership and merchant authorization. Check deployment support; older versions require EVM sign-in. Customer transaction gas and the 0.2% prepaid merchant service fee are separate; the current minimum service-credit top-up is 5 stablecoin units.

For API commands, environment credentials must supply both `YOURPAY_API_URL` and `YOURPAY_API_KEY`. A partial pair or explicitly empty values fail before sending a request; they never fall back to another saved account. To use saved login, unset both variables. Saved and environment credentials use the same origin validation: HTTPS is required except for loopback development, and URLs cannot contain credentials, paths, queries or fragments.

Saved login must be a regular UTF-8 JSON file no larger than 16 KiB. Invalid encoding, malformed JSON or oversized files stop the command without sending an authenticated request. Error output does not include file contents.

`init` currently supports Next.js App Router. It previews or creates server checkout/webhook routes, a button and explicit business hooks. It never overwrites existing files. Connect those hooks to authenticated server-side orders and durable, idempotent fulfillment. Scaffolding does not itself make a website payment-ready.

For a new BTC/LTC integration use `yourpay init --native --dry-run`, then `yourpay init --native`. This creates the same route/button paths with native quote/acceptance logic. Implement `resolveNativeOrder` (authenticate and load a persisted quote request UUID and price), `saveNativeQuote` (persist the snapshot and immutable acceptance options), `saveNativeInvoice` (attach the accepted invoice ID idempotently), and `fulfillPayment` (match exact native amounts and atomically grant access). The route does not return checkout before the invoice-save hook completes. Do not automatically create a new request ID or quote after uncertain acceptance. Existing files are preserved; this is not an automatic stable-to-native migration. For the combined inspection, scaffolding and diagnosis flow, use `yourpay connect --native --offline` to preview and `yourpay connect --native --apply --offline` to generate. The report preserves `--native` in its suggested apply command. Without `--native`, new integrations default to stable tokens. Neither mode replaces existing integration files.

Generated webhook routes return 503 when `YOURPAY_WEBHOOK_SECRET` is absent or empty, 400 when body/signature/event verification fails, and 503 when fulfillment cannot commit. Only verified non-payment notifications or successful payment fulfillment receive 204. A configuration failure must be fixed in the merchant server environment; retry alone cannot configure the key. Existing files are not automatically updated.

`doctor` checks integration and deployed-service readiness. `networks` lists actually configured payment options. `listen --forward-to http://localhost:3001/api/yourpay/webhook` forwards TEST events using `YOURPAY_LISTEN_SECRET`; use the same secret at the local merchant endpoint. The listener does not acknowledge production deliveries. `skill` prints the bundled Skill location.

The `business_hooks` diagnostic rejects missing, empty, comment-only and setup-placeholder adapters. A passing result only establishes non-comment source without setup markers; it neither parses/executes merchant code nor validates exports, authorization or fulfillment. Use application tests and an actual purchase to establish those behaviors.

New scaffolds record `paymentFlow` in `yourpay.config.json`. For existing adapters, `connect --native` reports a migration action when the recorded flow is stable-token, or a review action when metadata is missing/invalid. It preserves existing files and configuration. This record is configuration evidence only; it cannot prove the current code implements that flow. Running ordinary `connect` on a recorded native project preserves that selection instead of requesting a stable-token migration.

All commands emit JSON for coding agents. Install `skills/yourpay-integrate` into your agent's skill directory and ask it to integrate your existing website. Never supply wallet private keys or publish server API credentials in client bundles.

`yourpay integration-status` reads authenticated setup and historical purchase evidence: website/webhook configuration, a paid customer order, and an acknowledged completion event for a paid order at the currently configured callback URL. It returns `nextAction` for the remaining integration step. HTTP acknowledgement does not prove business fulfillment; the result always leaves that verification explicit. Historical success also does not establish current worker health or production readiness. This command uses the selected CLI credentials; verify they belong to the intended website.

Online `doctor` / `connect` also checks the website merchant's receiving channels. A configured platform network alone is insufficient: stable-token channels require a verified wallet of the matching family (an EVM identity may use its verified identity address), and BTC/LTC require a verified enabled binding for that exact network. One matching channel is enough to continue; add other wallets later. Missing or unreadable native bindings cannot produce a successful receiving-channel check. This diagnostic does not replace invoice-time checks or live payment acceptance.

`doctor` uses the website's effective `.env` / `.env.local` configuration, with process environment taking precedence, for online merchant checks. It falls back to saved CLI login only when neither website API URL nor key is configured. A partial pair fails instead of silently diagnosing another account. Secret values are not printed. Other API commands continue to use process credentials or saved login; they do not implicitly load a website dotenv file.

## Native BTC/LTC commands (operator opt-in)

These commands target the native APIs, which require a verified receiving branch and explicit operator enablement. Native hosted checkout implements address/amount display, both amount-bearing and address-only QR, and wallet-request links. Real wallet interoperability and public-network acceptance remain open. Default `init` targets stable tokens; `init --native` scaffolds the separate native flow described above.

Run `yourpay networks` to discover exact IDs in `nativeNetworks`. Only entries with `invoiceApiEnabled: true` are candidates for the native quote flow; merchant eligibility and live health are checked separately by the service. Do not infer support from roadmap entries or enable operator settings just to pass integration checks.

Save `native-quote.json` with `requestId` (a UUID generated once and persisted with the merchant order), `orderId`, configured `network`, `denomination` (`USD` or `native`) and decimal-string `amount`. Do not include rates, confirmations, wallet keys or credentials. Then run:

```sh
yourpay native-quote --input native-quote.json
yourpay native-quote-get --id QUOTE_UUID
```

Save the resulting quote ID and snapshot. Create `native-invoice.json` containing `quoteId`, `title` and optional `returnUrl` / `paymentWindowSeconds` (60–3600), then run:

```sh
yourpay native-invoice --input native-invoice.json
yourpay invoice-get --id INVOICE_UUID
yourpay invoice-operations --id INVOICE_UUID
```

The server chooses the price source and confirmation policy. File payloads are limited to 64 KiB and unsupported fields are rejected before sending. Credentials come from login or server environment variables, never command-line arguments. Requests emit API responses as JSON; errors emit JSON on stderr and exit nonzero.

Persist the accepted invoice ID with your merchant order and send the customer to its `checkoutUrl`. Only the backend's verified payment event and durable, idempotent fulfillment can authorize delivery; opening a wallet or returning to your website cannot.

On transport failure, reuse the exact saved file. No command automatically generates a new request ID, requotes or accepts a changed price. An expired quote needs an intentional new quote request with a new persisted UUID; first reconcile any uncertain invoice acceptance so that a replacement cannot create a second purchase. Returning a checkout URL does not prove the target deployment passed public-network or production acceptance.
# Unified first connection

Run `yourpay connect --offline --cwd /path/to/site` to preview the integration and receive one JSON report covering framework, business-code candidates, credential requirements, diagnostics and next actions. `yourpay connect --apply --offline` generates the supported Next.js adapter. Repeating it preserves existing code. Run `yourpay connect` after configuring the website server environment for online checks.

Business candidates are filename hints and must be reviewed. By default this command does not copy credentials. It does not install dependencies or prove fulfillment. After reviewing the project's scripts, pass `--check typecheck,test,build` to execute selected existing scripts with the detected package manager. Supported names are `typecheck`, `test`, `build`, `test:e2e`; scripts run sequentially, stop on failure, and have a two-minute timeout each. Failures/timeouts produce a nonzero CLI exit code. Script output is suppressed to protect secrets; the JSON report contains command, duration, status and exit code. Run a failed command locally to investigate. Passing scripts do not establish payment-specific coverage or production readiness.

Use `yourpay connect --configure-env --offline` explicitly to configure `.env.local` using browser-login credentials, or both YOURPAY_API_URL and YOURPAY_API_KEY from the current environment. Supply YOURPAY_WEBHOOK_SECRET through the environment; it must be the existing secret registered with your merchant webhook. This command does not create or rotate a hosted secret. It preserves unrelated variables and appends missing payment variables; identical configuration returns `already_configured`. Conflicting payment values, unsafe files, unfinished quoted values, tracked `.env.local`, and existing payment settings in `.env` are refused. Secret values are neither command arguments nor output. The Git ignore rule is installed before credentials are written. New files request owner-only Unix permissions; Windows access control depends on the project directory. Production hosting variables still require configuration in that environment.

### Owner-approved Webhook configuration

On deployments supporting schema 46, save a JSON file with exactly `name`, `appUrl`, and `webhookUrl`. Use explicit `null` only when intentionally removing a URL. With a valid merchant CLI credential:

```sh
yourpay settings-request --input settings.json --rotate-webhook-secret
# The merchant opens the returned approvalUrl and reviews the changes and key fingerprint.
yourpay settings-deliver --id REQUEST_UUID --delivery-key-id LOCAL_KEY_UUID --cwd /path/to/site
```

Keep the returned `id` and `deliveryKeyId` for the second command. The private delivery key stays in the CLI configuration directory (Windows current-user DPAPI; owner-only file on Unix); only its public key is submitted. The merchant must explicitly consent to replacing the Webhook secret. Fetching configuration does not grant that consent. The CLI decrypts directly into local server configuration without printing plaintext. Delivery can be retried with the same IDs and original credential until the ten-minute request expiry, including after `settings-poll` consumed its one-time status result. A retry does not rotate again. Preserve the local key directory until delivery is complete; losing it prevents decryption. Do not automatically recreate a request after an uncertain network outcome.

For initial setup, check that the project has no conflicting payment configuration before requesting rotation. For an existing integration, replacing the hosted secret requires coordinating the server environment update; this CLI deliberately does not overwrite conflicting local values. Existing queued Webhook events can retain their prior signing secret. Do not claim a production secret migration is complete from a successful local write. Omit `--rotate-webhook-secret` when only changing the three ordinary settings. These commands do not activate live payments or verify business fulfillment.

Online reports also include `verification.hostedPaymentEvidence` from the website's configured merchant account: historical paid invoices and HTTP webhook acknowledgements. These are explicitly scoped to merchant history, not this checkout build, and cannot establish fulfillment or production readiness. Missing/unavailable evidence is never converted into success. Diagnostics check that both default Next.js payment handler files exist, including when a previous scaffold is partial; existing merchant hook files remain untouched.

Repository acceptance: `npm run test:next` builds the local SDK and installs a fresh Next.js 16.3.4 test project, builds the generated adapter with webpack, and checks default failure responses over actual production-server HTTP. It requires registry access and retains the isolated project/build log. This verifies the unconfigured scaffold; it does not demonstrate that a merchant's business hooks or real payments are complete.

`npm run test:next:business` additionally connects the generated handlers to a loopback reference merchant and payment service through the packed SDK. It verifies server-authoritative order data, concurrent creation, raw signature rejection, fulfillment rollback and idempotent retry over HTTP. The test uses a fixture session, PGlite and an actual local Hardhat transaction with two confirmations. `npm run test:next:postgres` runs the business flow against an isolated native PostgreSQL database alongside the database acceptance suite. Neither test verifies public-chain finality or a production merchant's authentication and fulfillment implementation.

The business HTTP drill now executes a real local Hardhat token payment and waits for two confirmations through the independent scanner before exercising the generated webhook handler. It no longer injects synthetic settlement. Merchant authentication remains a test session, the database is PGlite, and the signing wallet is programmatic; this is local integration acceptance rather than public-network readiness.

`npm run test:next:postgres` runs the same Next.js/local-chain business scenario against an isolated native PostgreSQL database and asserts the actual database backend. It also runs the existing native database concurrency/restart suite. The combined HTTP scenario still uses a fixture customer session and loopback webhook delivery; it does not perform public-network payments or restart the database mid-purchase.
## MCP connection

CLI API responses are capped at 1 MiB after decompression, with a 15-second default request deadline including body reads. Invalid or oversized responses can leave a write outcome unknown: inspect the saved order before retrying with identical IDs/options. The CLI does not automatically retry order creation. Error messages redact the API key used for that request.

With `@yourpay/mcp` installed alongside this CLI, `yourpay login --url https://your-deployment` followed by `yourpay mcp` prints a client configuration referencing the saved local login file without printing the key. Copy it into an MCP client supporting `mcpServers`. Do not combine that file source with API-key/API-URL environment variables. See [MCP setup](../mcp/README.md) for local package installation and environment-based alternatives. No npm release is currently published.
